ULTIMATE MATCH — playable browser prototype

HOW TO PLAY
1. Open index.html in a modern browser (Chrome recommended).
2. Choose HEAD TO HEAD or VS ATTACK.
3. Use the arrow buttons (or WASD/arrow keys) to move.
4. PASS sends the ball forward; SHOOT kicks toward the AI goal.
5. SWITCH moves your controlled player to a teammate; hold SPRINT to run faster.

IMPORTANT
This is a playable 2D prototype, not EA SPORTS FC Mobile and not an APK.
It uses fictional gameplay and a fan-made interface. It does not include EA's licensed assets,
online matchmaking, or real FC Mobile player models.
